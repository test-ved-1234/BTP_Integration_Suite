import com.sap.gateway.ip.core.customdev.util.Message

// if metadata use sfdc field name and object name
// if lookup use sfdc api name

def String generate_url(String field_or_api_name, String object_name, String value, String site_name, String validation_id) {
    if (object_name.toLowerCase() != "x") {
        site_name_ASCII = site_name.replace(" ","%20").replace("_","%26").replace("&","%26")
        field_or_api_name_ASCII = field_or_api_name.replace("_","%5F")
        object_name_ASCII = object_name.replace("_","%5F")
		value_ASCII = value.replace(" ","%20").replace("_","%5F")
        validation_id_ASCII = validation_id.replace("_","%5F")
        if (field_or_api_name_ASCII != validation_id_ASCII) {
            sfdc_url = "https://excelitas--partnerdv3.sandbox.my.salesforce.com/services/data/v65.0/query?q=SELECT+Id%2C+MasterLabel%2C+Site%5F%5Fc%2C+"+field_or_api_name_ASCII+"%2C+"+validation_id_ASCII+"+FROM+"+object_name_ASCII+"+WHERE+"+validation_id_ASCII+"+like+%27%25"+value_ASCII+"%25%27+and+Site%5F%5Fc+like+%27%25"+site_name_ASCII+"%25%27"
        } else {
        sfdc_url = "https://excelitas--partnerdv3.sandbox.my.salesforce.com/services/data/v65.0/query?q=SELECT+Id%2C+MasterLabel%2C+Site%5F%5Fc%2C+"+field_or_api_name_ASCII+"+FROM+"+object_name_ASCII+"+WHERE+"+field_or_api_name_ASCII+"+like+%27%25"+value_ASCII+"%25%27+and+Site%5F%5Fc+like+%27%25"+site_name_ASCII+"%25%27"
        }
    }
    if (object_name.toLowerCase() == "x") {
        site_name_ASCII = site_name.replace(" ","%20").replace("_","%26").replace("&","%26")
        field_or_api_name_ASCII = field_or_api_name.replace("_","%5F")
		value_ASCII = value.replace(" ","%20").replace("_","%5F")
        validation_id_ASCII = validation_id.replace("_","%5F")
        sfdc_url = "https://excelitas--partnerdv3.sandbox.my.salesforce.com/services/data/v65.0/query?q=SELECT+id%2C+Site%5F%5Fc%2C+"+validation_id_ASCII+"+from+"+field_or_api_name_ASCII+"+where+"+validation_id_ASCII+"+like+%27%25"+value_ASCII+"%25%27+and+Site%5F%5Fc+like+%27%25"+site_name_ASCII+"%25%27"
    }
	
    return sfdc_url
}

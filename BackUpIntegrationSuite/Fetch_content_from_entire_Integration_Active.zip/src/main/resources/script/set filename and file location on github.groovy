import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def headers = message.getHeaders()
    def disposition = headers["content-disposition"]
    def packageId = message.getProperty("packageId")
    def curr_date = message.getProperty("Current_Date")
    def artifactVersion = message.getProperty("artifactVersion")
    // remove afterwards
    curr_date = "_"
    // message.setProperty("curnt_date", curr_date.replace("T",""))
    // message.setProperty("curnt_date__", curr_date.replace("T","")+"--")
    def filename_ext = disposition.split("filename=")[-1].replace("\"","").split("\\.")
    def github_filename =  filename_ext[0] + "_" + artifactVersion + "." + filename_ext[1]
    def github_file = "%2F"+ packageId +"%2F" + github_filename
    message.setProperty("github_filename", github_filename)
    message.setProperty("github_file", github_file)
    message.setProperty("github_commit","Create_"+github_filename.split("\\.")[0])
    return message;
    }
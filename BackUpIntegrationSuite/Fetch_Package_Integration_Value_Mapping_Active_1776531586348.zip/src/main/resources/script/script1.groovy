import com.sap.gateway.ip.core.customdev.util.Message
import java.nio.charset.StandardCharsets

def Message processData(Message message) {
    // 1. Get binary content as byte array
    byte[] binaryContent = message.getBody(byte[])
    
    // 2. Define unique boundary
    String boundary = "----SAPCPIBoundary" + System.currentTimeMillis()
    
    // 3. Build the form-data structure
    // Note: ISO_8859_1 is used to ensure binary bytes are not corrupted during string conversion
    StringBuilder sb = new StringBuilder()
    sb.append("--").append(boundary).append("\r\n")
    sb.append("Content-Disposition: form-data; name=\"file\"; filename=\"file_"+System.currentTimeMillis()+".zip\"\r\n")
    sb.append("Content-Type: application/octet-stream\r\n\r\n")
    
    // Convert current builder to bytes, then append binary content
    byte[] headerBytes = sb.toString().getBytes(StandardCharsets.ISO_8859_1)
    byte[] footerBytes = ("\r\n--" + boundary + "--").getBytes(StandardCharsets.ISO_8859_1)
    
    // Combine all parts into a final byte array
    byte[] finalPayload = new byte[headerBytes.length + binaryContent.length + footerBytes.length]
    System.arraycopy(headerBytes, 0, finalPayload, 0, headerBytes.length)
    System.arraycopy(binaryContent, 0, finalPayload, headerBytes.length, binaryContent.length)
    System.arraycopy(footerBytes, 0, finalPayload, headerBytes.length + binaryContent.length, footerBytes.length)
    
    // 4. Set Headers and Body
    message.setHeader("Content-Type", "multipart/form-data; boundary=" + boundary)
    message.setBody(finalPayload)
    
    return message
}

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;
import com.sap.it.api.securestore.*;
import com.sap.it.api.mapping.*;


//Import for Fetching Secure Parameters
import com.sap.it.api.ITApi;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;

def String GetProperty(String P1,MappingContext context) {
    String value2 = context.getProperty(P1);
    return value2;
}


def void MergeData(String[] Field1, String[] Field2, String[] Field3, String[] Field4, String[] Field5, String[] Payroll_ID, String[] FirstName, String[] LastName, String[] Message, String[] Errors, Output output, MappingContext context){
    String Ans = "";
    
    for(i=0;i<Payroll_ID.size();i++){
        
        Ans = Ans + "<tr><td>" + Field1[i] + "</td><td>" + Payroll_ID[i] + "</td><td>"  + FirstName[i] + "</td><td>"  + LastName[i] + "</td><td>" + Message[i] + "</td><td>" + Errors[i] + "</td></tr>";
        
    }
    
    output.addValue(Ans);
}


import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

       def map = message.getProperties();
       def employees = map.get("Employee_Id");
       def companies = map.get("companies");

       ArrayList employeeList = employees.split(",");
       ArrayList companyList = companies.split(",");
       
       def query_employee = "";
       def query_company = "";

// Split input/adhoc employees and frame query       
       if( employees != null && employees != "" && employeeList.size() > 0 )
       {
           query_employee = "AND person_id_external IN (";
           for(def i = 0; i < employeeList.size(); i++ )
           {
               query_employee = query_employee + "'" + employeeList[i] + "'";
               
               if( i + 1 < employeeList.size() )
               {
                   query_employee += ",";
               }
           }
           query_employee += ")";
       }

// Split input companies and frame query       
       if( companies != null && companies != "" && companyList.size() > 0 )
       {
           query_company = "AND company IN (";
           for(def i = 0; i < companyList.size(); i++ )
           {
               query_company = query_company + "'" + companyList[i] + "'";
               
               if( i + 1 < companyList.size() )
               {
                   query_company += ",";
               }
           }
           query_company += ")";
       }

       message.setProperty("employee_query", query_employee);
       message.setProperty("company_query", query_company);

       return message;
}
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

def Message InitiateHashMap(Message message) 
{

 def map = message.getProperties();
 String Temp = "0"

 HashMap<String, String> hmap1 = new HashMap<String, String>();
 HashMap<String, String> hmap2 = new HashMap<String, String>();

 message.setProperty("Pers_HireRehire_Success",hmap1);
 message.setProperty("Pers_HireRehire_Adhoc",hmap2);


 HashMap<String, String> cacheData1 = map.get("Pers_HireRehire_Success");
 cacheData1.put("PersHireRehireSuccess",Temp)
 message.setProperty("Pers_HireRehire_Success",cacheData1);
 
 HashMap<String, String> cacheData2 = map.get("Pers_HireRehire_Adhoc");
 cacheData2.put("PersHireRehireAdhoc",Temp)
 message.setProperty("Pers_HireRehire_Adhoc",cacheData2);
 
   return message;
}


//Increment the Personal HireRehire Dated record
def Message Incr_Pers_HireRehire_Success(Message message) {
    
    String RecordsFound = "";
    //def map = message.getHeaders();
    def map = message.getProperties();
    def output = map.get("Pers_HireRehire_Success");
    def value=output.get("PersHireRehireSuccess");
    
    int count = value.toInteger() + 1;
    
    HashMap<String, String> cacheData = map.get("Pers_HireRehire_Success");
	cacheData.put("PersHireRehireSuccess",count.toString())
	message.setProperty("Pers_HireRehire_Success",cacheData);
	
	return message;
}

//Get the Personal HireRehire Dated record count
def Message Get_Pers_HireRehire_count(Message message) {
    
    String RecordsFound = "";

    def map = message.getProperties();
    
    def output2 = map.get("Pers_HireRehire_Success");
    def value2=output2.get("PersHireRehireSuccess");  
 
    message.setProperty("Pers_HireRehire_Success_count",value2);
        
	return message;
}


//Update HireRehire Run Type
def Message UpdateRunType_HireRehire(Message message) {
    
    String RecordsFound = "";
    def map = message.getProperties();
    def adhoc_val = map.get("Adhoc_Run"); //Get On demand Run
    
    HashMap<String, String> cacheData = map.get("Pers_HireRehire_Adhoc");
	cacheData.put("PersHireRehireAdhoc",adhoc_val.toString())
	message.setProperty("Pers_HireRehire_Adhoc",cacheData);
	
	return message;
}

//Get HireRehire Run Type
def Message Get_HireRehire_RunType(Message message) {
    
    String RecordsFound = "";

    def map = message.getProperties();
    
    def output2 = map.get("Pers_HireRehire_Adhoc");
    def value2=output2.get("PersHireRehireAdhoc");  
 
    message.setProperty("Pers_HireRehire_Adhoc",value2);
        
	return message;
}
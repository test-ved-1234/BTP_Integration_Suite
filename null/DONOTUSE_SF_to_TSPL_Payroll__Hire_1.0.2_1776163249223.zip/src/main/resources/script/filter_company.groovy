import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import groovy.xml.*;
import groovy.util.*;

def Message processData(Message message) {

    InputStream is  = message.getBody(java.io.InputStream);
	String xml = is.getText("UTF-8");

    def map = message.getProperties();
    def legalEntities = map.get("companies");
    if(legalEntities != null && legalEntities != ""){
        List<String> le = legalEntities.split(",");
    }
    def sfObject = new XmlParser().parseText(xml);
    def sfPersons = sfObject.'**'.findAll{p -> p.name().toString() == "person" };
    
    for(def i = 0; i < sfPersons.size(); i++){
        def sfPerson = sfPersons[i];
        
        if(sfPerson.person_id_external != null && sfPerson.person_id_external.text() != ""){

            def sfEmploymnets = sfPerson.employment_information.'**'.findAll{p -> p.name().toString() == "employment_information" };
            for(def j = 0; j < sfEmploymnets.size(); j++){

                //Trim Payload to get valid legal entities
                if(legalEntities != null && legalEntities != ""){
                    List<String> le = legalEntities.split(",");
                    def sfEmploymnet = sfEmploymnets[j];
                    if(!le.contains(sfEmploymnet.job_information.company.text())){
                        sfEmploymnet.replaceNode{};
                    }
                }
            }
        }
    }
    
    xml = XmlUtil.serialize(sfObject);
	is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
	message.setBody(is);
    return message;
}
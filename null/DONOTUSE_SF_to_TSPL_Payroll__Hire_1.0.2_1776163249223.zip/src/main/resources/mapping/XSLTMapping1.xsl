<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" 
xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns4="http://notification.event.successfactors.com">
    
    <xsl:output method="xml" version="1.0" encoding="utf-8" indent="no" omit-xml-declaration="yes" />

	<xsl:template match="/">
		<Events>
			<xsl:for-each select="ns4:ExternalEvent/ns4:events/ns4:event">
				<Event>
					<Type>
						<xsl:value-of select="substring-after(../../ns4:externalEventMeta/ns4:type,'AssignmentInformation.')" />
					</Type>
					<Keys>
						<xsl:for-each select="ns4:entityKeys/ns4:entityKey">
							<xsl:element name="{name}" >
								<xsl:value-of select="value" />
							</xsl:element>
						</xsl:for-each>
					</Keys>
					<Params>
						<xsl:for-each select="ns4:params/ns4:param">
							<xsl:element name="{name}" >
								<xsl:value-of select="value" />
							</xsl:element>
						</xsl:for-each>
					</Params>
					<query>
						<filter>
							<xsl:apply-templates select="ns4:entityKeys/ns4:entityKey"/>
						</filter>
					</query>
				</Event>
			</xsl:for-each>
		</Events>
	</xsl:template>

	<xsl:template match="ns4:entityKeys/ns4:entityKey">(<xsl:value-of select="name" /> eq '<xsl:value-of select="value" />')<xsl:if test ="position() != last()"> and </xsl:if>
	</xsl:template>

</xsl:stylesheet>

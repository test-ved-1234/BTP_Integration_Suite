<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema">
    <xsl:output method="xml" version="1.0" encoding="utf-8" indent="yes" omit-xml-declaration="yes"/>
    
    <xsl:template match="node()|@*">
        <xsl:copy>
            <xsl:apply-templates select="node()|@*"/>
        </xsl:copy>
    </xsl:template>
    
    	<!-- Get parameters -->
	<xsl:param name="LSRD"/>
	<xsl:param name="CurrentTime"/>

    <xsl:template match="queryCompoundEmployeeResponse/CompoundEmployee">
        

    <!-- Conditions for the data filter:
	    -->
       	<xsl:if test="(person/employment_information[1]/job_information[1][(event = '26' or event = 'NS')]/event_reason != '') and 
       	
       	(person/employment_information[1][assignment_class = 'ST' and isContingentWorker = 'false']/job_information[1][(employee_class = 'REG')]/emplStatus = 'T') 
       	">
     	     
       	     <xsl:copy-of select="."/>
        </xsl:if>


    </xsl:template>
</xsl:stylesheet>
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


def Message processData(Message message) {
       
       String timeStamp = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
       def body = message.getBody(java.lang.String) as String;
       def messageLog = messageLogFactory.getMessageLog(message);
       
       String MailBody = body.substring(body.indexOf("<!DOCTYPE html>"),body.size());
       
       String temp = body.substring(0,body.indexOf("<!DOCTYPE html>"));
       
       messageLog.addAttachmentAsString(timeStamp + " Mail Paramters", temp, "text/text");
       messageLog.addAttachmentAsString(timeStamp + " Mail Body", MailBody, "text/html");
       
       String ToMail = temp.substring(0,body.indexOf("\n"));
       String Subject = temp.substring(body.indexOf("\n") + 1,temp.size());
       
       ToMail = ToMail.replaceAll("ToMail:","");
       ToMail = ToMail.replaceAll(" ","");
       
       Subject = Subject.replaceAll("Subject:","");

       map = message.getProperties();
       
       message.setProperty("ToMail", ToMail);
       message.setProperty("Subject", Subject);
       
       message.setBody(MailBody);
       return message;
}
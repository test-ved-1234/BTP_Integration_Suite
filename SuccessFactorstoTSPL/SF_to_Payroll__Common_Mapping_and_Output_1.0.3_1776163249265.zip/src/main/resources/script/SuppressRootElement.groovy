import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.json.*
import groovy.json.JsonSlurper
import groovy.json.JsonOutput


def Message Suppress_element(Message message) {
    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)
    def list = json.record // Put the element name that needs to be supressed. In this case it was like /Payroll/record. we need to supress record.
    def output = JsonOutput.prettyPrint(JsonOutput.toJson(list))
    message.setBody(output)
    
    return message
}

def Message format_json(Message message) {    
    def payload = message.getBody(String)       
    def json = new JsonSlurper().parseText(payload)    
    def fieldsToConvert = ['PayMethod']        //Mention the field names that you want to convert     
        fieldsToConvert.each { f -> json.record[f] = json.record[f].toInteger()}    //What type of converted values should be whether float/Integer/Boolean

        fieldsToConvert = ['WorkingHours']        //Mention the field names that you want to convert     
        fieldsToConvert.each { f -> json.record[f] = json.record[f].toFloat()}  //What type of converted values should be whether float/Integer/Boolean
        
        message.setBody(JsonOutput.toJson(json))    
        
        return message
}
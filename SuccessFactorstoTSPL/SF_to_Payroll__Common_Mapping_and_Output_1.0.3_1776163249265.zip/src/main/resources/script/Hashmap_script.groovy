import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

class CompanyStruct{                 //Create the data structure to hold company data
    String companyId = ""
    String startDate = "";
    String companyName = "";
}

class DepartmentStruct{                 //Create the data structure to hold company data
    String departmentId = ""
    String startDate = "";
    String departmentName = "";
}

class Picklist{                      //Create the data structure to hold picklist data
    String externalCode = ""
    String label = "";
    String optionid = "";
}

def Message Init(Message message){
    HashMap<String, Picklist> mapPicklist = new HashMap<String, Picklist>();                   
    HashMap<String, String> labelStore = new HashMap<String, String>();                       
    HashMap<String, String> optionidStore = new HashMap<String,String>();                      
    
    HashMap<String, CompanyStruct> mapCompanyStruct = new HashMap<String, CompanyStruct>();    
    HashMap<String, String> startDateStore = new HashMap<String, String>();                    
    HashMap<String, String> CompanyStore = new HashMap<String,String>();                       

    HashMap<String, DepartmentStruct> mapDepartmentStruct = new HashMap<String, DepartmentStruct>();    
    HashMap<String, String> startDateStore1 = new HashMap<String, String>();                    
    HashMap<String, String> DepartmentStore = new HashMap<String,String>(); 

    message.setProperty("mapPicklistRelation",mapPicklist);             
    message.setProperty("labelStoreRelation",labelStore);               
    message.setProperty("optionidStoreRelation",optionidStore);         
    
    message.setProperty("mapPicklistReligionIDN",mapPicklist);          
    message.setProperty("labelStoreReligionIDN",labelStore);             
    message.setProperty("optionidStoreReligionIDN",optionidStore);       
    
    message.setProperty("mapPicklistReligionSGP",mapPicklist);          
    message.setProperty("labelStoreReligionSGP",labelStore);             
    message.setProperty("optionidStoreReligionSGP",optionidStore);        
    
    message.setProperty("mapCompanyStruct",mapCompanyStruct);                            
    message.setProperty("startDateStore",startDateStore);          
    message.setProperty("CompanyStore",CompanyStore);              

    message.setProperty("mapDepartmentStruct",mapDepartmentStruct);                            
    message.setProperty("startDateStore1",startDateStore1);          
    message.setProperty("DepartmentStore",DepartmentStore);  

    return message;
}

def Message cachePicklistValRelation(Message message){
    def body = message.getBody(java.lang.String);
    def properties = message.getProperties();
    
    HashMap<String, Picklist> mapPicklist = properties.get("mapPicklistRelation");   
    HashMap<String, String> labelStore = properties.get("labelStoreRelation");       
    HashMap<String, String> optionidStore = properties.get("optionidStoreRelation")  

    def xmlBody = new XmlParser().parseText(body);
    
    xmlBody.PickListValueV2.each {b ->                                   
        if(!mapPicklist.containsKey(b.externalCode.text()))              //Check if the existing store contains the picklist code
        {
            Picklist ee = new Picklist();
            mapPicklist.put(b.externalCode.text(),ee);    //Put the values of picklist to the HashMap               
            
            ee.externalCode = b.externalCode.text()     //Pass the externalCode of Picklist           
            ee.label = b.label_en_US.text();            //Pass the label of Picklist
            ee.optionid = b.optionId.text();            //Pass the option id of Picklist
            
        }
        else{
            
            Picklist be = mapPicklist.get(b.externalCode.text());  //Pass the externalCode of Picklist
            be.label = b.label_en_US.text();          //Pass the label of Picklist
            be.optionid = b.optionId.text();          //Pass the option id of Picklist
     }
    }
    
    mapPicklist.each {key, l ->
        labelStore.put(l.externalCode,l.label);      //Pass the picklist externalCode and label
        optionidStore.put(l.optionid, l.label);      //Pass the picklist option id and label
    }
    
    message.setProperty("optionidStoreRelation",optionidStore);  //Set the option id store
    message.setProperty("labelStoreRelation",labelStore);        // Set the label store
    return message;
}


def Message cachePicklistValRegionIDN(Message message){
    def body = message.getBody(java.lang.String);
    def properties = message.getProperties();
    HashMap<String, Picklist> mapPicklist = properties.get("mapPicklistReligionIDN");
    HashMap<String, String> labelStore = properties.get("labelStoreReligionIDN");
    HashMap<String, String> optionidStore = properties.get("optionidStoreReligionIDN")

    def xmlBody = new XmlParser().parseText(body);
    
    xmlBody.PickListValueV2.each {b -> 
        if(!mapPicklist.containsKey(b.externalCode.text()))
        {
            Picklist ee = new Picklist();
            mapPicklist.put(b.externalCode.text(),ee);
            ee.externalCode = b.externalCode.text()
            ee.label = b.label_en_US.text();
            ee.optionid = b.optionId.text();
            
        }
        else{
            
            Picklist be = mapPicklist.get(b.externalCode.text());
            be.label = b.label_en_US.text();
            be.optionid = b.optionId.text();
     }
    }
    
    mapPicklist.each {key, l ->
        labelStore.put(l.externalCode,l.label);
        optionidStore.put(l.optionid, l.label);
    }
    
    message.setProperty("optionidStoreReligionIDN",optionidStore);
    message.setProperty("labelStoreReligionIDN",labelStore);
    return message;
}

def Message cachePicklistValReligionSGP(Message message){
    def body = message.getBody(java.lang.String);
    def properties = message.getProperties();
    HashMap<String, Picklist> mapPicklist = properties.get("mapPicklistReligionSGP");
    HashMap<String, String> labelStore = properties.get("labelStoreReligionSGP");
    HashMap<String, String> optionidStore = properties.get("optionidStoreReligionSGP")

    def xmlBody = new XmlParser().parseText(body);
    
    xmlBody.PickListValueV2.each {b -> 
        if(!mapPicklist.containsKey(b.externalCode.text()))
        {
            Picklist ee = new Picklist();
            mapPicklist.put(b.externalCode.text(),ee);
            ee.externalCode = b.externalCode.text()
            ee.label = b.label_en_US.text();
            ee.optionid = b.optionId.text();
            
        }
        else{
            
            Picklist be = mapPicklist.get(b.externalCode.text());
            be.label = b.label_en_US.text();
            be.optionid = b.optionId.text();
     }
    }
    
    mapPicklist.each {key, l ->
        labelStore.put(l.externalCode,l.label);
        optionidStore.put(l.optionid, l.label);
    }
    
    message.setProperty("optionidStoreReligionSGP",optionidStore);
    message.setProperty("labelStoreReligionSGP",labelStore);
    return message;
}


def Message cacheDivision(Message message){
    def body = message.getBody(java.lang.String);
    def properties = message.getProperties();
    
    HashMap<String, CompanyStruct> mapCompanyStruct = properties.get("mapCompanyStruct");  //Create HashMap for Company Structure
    HashMap<String, String> startDateStore = properties.get("startDateStore");             //Create HashMap for Start date
    HashMap<String, String> CompanyStore = properties.get("CompanyStore")                  //Create HashMap for company id and description

    
    def xmlBody = new XmlParser().parseText(body);
    
    xmlBody.FODivision.each {b ->                                     //Loop through each company code fetched in the query 
        if(!mapCompanyStruct.containsKey(b.externalCode.text()))     // If the company id is not present in the existing structure
        {
            CompanyStruct ee = new CompanyStruct();           
            mapCompanyStruct.put(b.externalCode.text(),ee);          //Put the external code in the company structure map
            
            ee.companyId = b.externalCode.text()                     //Pass the externalCode to the structure
            ee.companyName = b.name.text();                          //Pass the name/description to the structure
            ee.startDate = b.startDate.text();                       //Pass the start date to the structure

        }
        else
        {
            CompanyStruct be = mapCompanyStruct.get(b.externalCode.text());  //Pass the externalCode to the structure
            be.companyName = b.name.text();                                  //Pass the name/description to the structure
            be.startDate = b.startDate.text();                               //Pass the start date to the structure
        }
    }
    
    mapCompanyStruct.each {key, l ->
        startDateStore.put(l.companyId,l.startDate);           //Pass the company id and startDate to the structure
        CompanyStore.put(l.companyId, l.companyName);          //Pass the companyId and name to the structure
    }
    
    message.setProperty("startDateStore",startDateStore);      //Set property for startDateStore
    message.setProperty("CompanyStore",CompanyStore);          //Set property for CompanyStore
    return message;
}


def Message cacheDepartment(Message message){
    def body = message.getBody(java.lang.String);
    def properties = message.getProperties();
    
    HashMap<String, DepartmentStruct> mapDepartmentStruct = properties.get("mapDepartmentStruct");  //Create HashMap for Department Structure
    HashMap<String, String> startDateStore1 = properties.get("startDateStore1");             //Create HashMap for Start date
    HashMap<String, String> DepartmentStore = properties.get("DepartmentStore")                  //Create HashMap for Department id and description

    
    def xmlBody = new XmlParser().parseText(body);
    
    xmlBody.FODepartment.each {b ->                                     //Loop through each Department code fetched in the query 
        if(!mapDepartmentStruct.containsKey(b.externalCode.text()))     // If the Department id is not present in the existing structure
        {
            DepartmentStruct ee = new DepartmentStruct();           
            mapDepartmentStruct.put(b.externalCode.text(),ee);          //Put the external code in the Department structure map
            
            ee.departmentId = b.externalCode.text()                     //Pass the externalCode to the structure
            ee.departmentName = b.name.text();                          //Pass the name/description to the structure
         //   ee.startDate1 = b.startDate.text();                       //Pass the start date to the structure

        }
        else
        {
            DepartmentStruct be = mapDepartmentStruct.get(b.externalCode.text());  //Pass the externalCode to the structure
            be.departmentName = b.name.text();                                  //Pass the name/description to the structure
         //   be.startDate = b.startDate.text();                               //Pass the start date to the structure
        }
    }
    
    mapDepartmentStruct.each {key, l ->
       // startDateStore.put(l.departmentId,l.startDate);           //Pass the Department id and startDate to the structure
        DepartmentStore.put(l.departmentId, l.departmentName);          //Pass the DepartmentId and name to the structure
    }
    
   // message.setProperty("startDateStore",startDateStore);      //Set property for startDateStore
    message.setProperty("DepartmentStore",DepartmentStore);          //Set property for DepartmentStore
    return message;
}
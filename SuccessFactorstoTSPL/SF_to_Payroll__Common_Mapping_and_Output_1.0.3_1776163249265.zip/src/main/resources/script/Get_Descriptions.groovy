import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;
import groovy.time.TimeCategory;
import java.util.HashMap;


def String GetRelationDesc(String in_Relation, MappingContext context)
{
    HashMap<String,String> labelStoreRelation = context.getProperty("labelStoreRelation");   //Get the property store from where you want to fetch the data

    ans = in_Relation;                   //Pass the input value as it is. This is done in case no value is found in the HashMap store then the input value can be passed out as output value
    if(in_Relation != "" || in_Relation != null || in_Relation != "null")  //Check whether the input is not empty
    {
        if(labelStoreRelation.containsKey(in_Relation))    //Check the input code is present on the HashMap store
        {
            ans = labelStoreRelation.get(in_Relation);     //If yes then get the label/description againt the input value
        }
    }
    return ans;   //Pass output value
}


def String GetRegionIDNDesc(String in_Region, MappingContext context)
{
    HashMap<String,String> labelStoreReligionIDN = context.getProperty("labelStoreReligionIDN");

    ans = in_Region;
    if(in_Region != "" || in_Region != null || in_Region != "null")
    {
        if(labelStoreReligionIDN.containsKey(in_Region))
        {
            ans = labelStoreReligionIDN.get(in_Region);
        }
    }
    return ans;
}


def String GetReligionSGPDesc(String in_Religion, MappingContext context)
{
    HashMap<String,String> labelStoreReligionSGP= context.getProperty("labelStoreReligionSGP");

    ans = in_Religion;
    if(in_Religion != "" || in_Religion != null || in_Religion != "null")
    {
        if(labelStoreReligionSGP.containsKey(in_Religion))
        {
            ans = labelStoreReligionSGP.get(in_Religion);
        }
    }
    return ans;
}

def String GetDivisionDesc(String in_Division, MappingContext context)
{
    HashMap<String,String> CompanyStore = context.getProperty("CompanyStore");

    ans = in_Division;
    
    if(in_Division != "" || in_Division != null || in_Division != "null")
    {
        if(CompanyStore.containsKey(in_Division))
        {
            ans = CompanyStore.get(in_Division);
        }
    }
    return ans;
}


def String GetDepartmentDesc(String in_Department, MappingContext context)
{
    HashMap<String,String> DepartmentStore = context.getProperty("DepartmentStore");

    ans = in_Department;
    
    if(in_Department != "" || in_Department != null || in_Department != "null")
    {
        if(DepartmentStore.containsKey(in_Department))
        {
            ans = DepartmentStore.get(in_Department);
        }
    }
    return ans;
}
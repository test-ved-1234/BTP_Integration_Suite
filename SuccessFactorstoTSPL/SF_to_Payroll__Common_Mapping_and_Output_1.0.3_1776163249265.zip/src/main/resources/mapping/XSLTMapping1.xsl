<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0"
    xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" version="1.0" encoding="utf-8" indent="yes" omit-xml-declaration="yes"/>
    

    <!-- Get Params -->
	<xsl:param name="empid"/>
    <xsl:param name="fname"/>
    <xsl:param name="lname"/>
    <xsl:param name="Message"/>
    <xsl:param name="Errors"/>


	<xsl:template match="/Response">

	                 <record>
	                    <Field_1>
        				     <xsl:text>SuccessFactors to Payroll</xsl:text>
            	        </Field_1>

	                    <Field_2>
        				     <xsl:text>004</xsl:text>
            	        </Field_2>
            	        
	                    <Field_3>
        				     <xsl:text>API Error Occurred</xsl:text>
            	        </Field_3>

	                    <Field_4>
        				     <xsl:text></xsl:text>
            	        </Field_4>

	                    <Field_5>
        				     <xsl:text>Check details and take appropriate action.</xsl:text>
            	        </Field_5>
            	        
            	        <Payroll_ID>
        				   <xsl:value-of select="$empid"/>
            	        </Payroll_ID>

            	        <FirstName>
        				   <xsl:value-of select="$fname"/>
            	        </FirstName>
            	        
            	        <LastName>
        				   <xsl:value-of select="$lname"/>
            	        </LastName>

            	        <Message> 
            	            <xsl:value-of select="$Message"/>  
            	        </Message>

            	        <Errors> 
            	            <xsl:value-of select="$Errors"/>  
            	        </Errors>
                    </record>

	</xsl:template>
</xsl:stylesheet>
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0"
    xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" version="1.0" encoding="utf-8" indent="yes" omit-xml-declaration="yes"/>
    
    <!-- Get Params -->
	<xsl:param name="FileType"/>
    

    <xsl:template match="/">
		<payroll>
			<xsl:apply-templates select="/payroll/record"/>
		</payroll>
	</xsl:template>
    
	<xsl:template match="payroll/record">
	    <xsl:if test="EMP_NO != ''">
          <record>
              
        <!-- Record Type -->                
                        <Record_Type>
                    	   <xsl:value-of select="$FileType"/>
                        </Record_Type>
                        
        <!-- Employee Country -->                
                        <Emp_Country>
                    	   <xsl:value-of select="Emp_Country"/>
                        </Emp_Country>                

        <!-- First Name -->
        				<firstname>
            	          <xsl:value-of select="EMP_FIRST_NAME"/>
            	        </firstname>      
 
          <!-- Middle Name -->
        				<middlename>
            	          <xsl:value-of select="EMP_MIDDLE_NAME"/>
            	        </middlename> 
 
         <!-- Last Name -->
        				<surname>
            	          <xsl:value-of select="EMP_LAST_NAME"/>
            	        </surname>  
 
        <!-- Display Name -->
        				<emp_alias>
            	          <xsl:value-of select="DISPLAY_NAME"/>
            	        </emp_alias>  
 
        <!-- Initial-->
        				<emp_native_name>
            	          <xsl:value-of select="INITIAL"/>
            	        </emp_native_name>  
 
        <!-- Title -->
        				<sex_title>
            	          <xsl:value-of select="SEX_TITLE"/>
            	        </sex_title>  
 
        <!-- Gender -->
        				<sex>
            	          <xsl:value-of select="SEX"/>
            	        </sex>  
 
        <!-- Marital Status -->
        				<marital_status>
            	          <xsl:value-of select="MARITAL_STATUS"/>
            	        </marital_status> 
 
        <!-- Nationality -->
        				<national_code>
            	          <xsl:value-of select="NATIONAL_CODE"/>
            	        </national_code> 
 
        <!-- Local Employee Number -->
        				<batch_no>
            	          <xsl:value-of select="BATCH_NO"/>
            	        </batch_no> 
 
         <!-- Employee Number -->
        				<emp_no>
            	          <xsl:value-of select="substring(EMP_NO,2,8)"/>
            	        </emp_no> 
 
        <!-- Date of birth -->
        				<dob>
            	          <xsl:value-of select="DOB"/>
            	        </dob> 
 
        <!-- Country/ Region of Birth -->
        				<citizen_code>
            	          <xsl:value-of select="NATIONAL_CODE"/>
            	        </citizen_code> 
 
        <!-- Country of Birth -->
        				<dobctry>
            	          <xsl:value-of select="BIRTH_COUNTRY"/>
            	        </dobctry> 
 
        <!-- Local Employee Number  -->
        				<new_ic>
            	          <xsl:value-of select="LOCAL_EMPNO"/>
            	        </new_ic> 
 
        <!-- Address  -->
        				<addr2>
            	          <xsl:value-of select="BATAM_ADDR1"/>
            	        </addr2> 
            	        
        <!-- Region -->
        				<state>
            	          <xsl:value-of select="BATAM_STATE"/>
            	        </state> 
 
        <!-- Postal Code -->
        				<postal_code>
            	          <xsl:value-of select="BATAM_ZIP"/>
            	        </postal_code> 
 
        <!-- Country/Region-->
        				<country_code>
            	          <xsl:value-of select="BATAM_COUNTRY"/>
            	        </country_code> 
            	        
        <!-- Phone no country_code-->
        				<mobile_phone_cc>
            	          <xsl:value-of select="MOBILE_NO_CC"/>
            	        </mobile_phone_cc>            	        
            	        
        <!-- Phone no -->
        				<mobile_phone>
            	          <xsl:value-of select="MOBILE_NO"/>
            	        </mobile_phone>              	        
            	        
        <!-- Email information -->
        				<email_ac_no>
            	          <xsl:value-of select="BUS_EMAIL"/>
            	        </email_ac_no>             	        
            	        
         <!-- Employee Status-->
        				<termination_status>
            	          <xsl:value-of select="EMPL_STATUS"/>
            	        </termination_status>              	        
            	        
          <!-- Working Days Per Week-->
        				<day_work_perweek>
            	          <xsl:value-of select="DAYS_PER_WEEK"/>
            	        </day_work_perweek>            	        
            	        
          <!-- Join date -->
        				<hired_date>
            	          <xsl:value-of select="HIRED_DATE"/>
            	        </hired_date>               	        
            	        
          <!-- End date-->
        				<termination_date>
            	          <xsl:value-of select="CONTRACT_ENDDATE"/>
            	        </termination_date>    
            	        
        <!--  Paygroup -->
        				<pay_group>
            	          <xsl:value-of select="PAY_GROUP"/>
            	        </pay_group>              	        
            	        
        <!--  Paytype -->
        				<pay_type>
            	          <xsl:value-of select="PAY_TYPE"/>
            	        </pay_type>             	        
 
         <!-- Annual hours -->
        				<hrs_work_peryear>
            	          <xsl:value-of select="ANNUAL_HOURS"/>
            	        </hrs_work_peryear>   
        
          <!-- National ID -->
        				<char1>
            	          <xsl:value-of select="NATIONAL_ID"/>
            	        </char1>          
        
        <!-- Local Job Title -->
        				<char3>
            	          <xsl:value-of select="LOCAL_JOB_TITLE"/>
            	        </char3>        
        
         <!-- Place Of Birth -->
        				<char6>
            	          <xsl:value-of select="BIRTH_PLACE"/>
            	        </char6>         
        

         <!-- Religion -->
        				<religion_code>
            	          <xsl:value-of select="RELIGION_CODE"/>
            	        </religion_code> 
            	        
         <!-- Original Hire Date -->
        				<ori_hired_date>
            	          <xsl:value-of select="ORIGINAL_HIRED_DATE"/>
            	        </ori_hired_date>            	        

         <!-- Emergency Home  -->
        				<emg_address1>
            	          <xsl:value-of select="EMERGENCY_ADDR"/>
            	        </emg_address1>   

         <!-- Emergency Relationship  -->
        				<emg_contact_relation>
            	          <xsl:value-of select="EMERGENCY_RELATION_P"/>
            	        </emg_contact_relation>            	        
            	        
         <!-- Emergency Mobile  -->
        				<emg_tel>
            	          <xsl:value-of select="EMERGENCY_MOBILE_P"/>
            	        </emg_tel>            	        
            	                    	        
          <!-- Emergency contact person name  -->
        				<emergency_contact>
            	          <xsl:value-of select="EMERGENCY_NAME_P"/>
            	        </emergency_contact>             	        
            	        
            	        
            	        
            	        
            	        
 
          </record>
        </xsl:if>
	</xsl:template>
</xsl:stylesheet>

<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0"
    xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" version="1.0" encoding="utf-8" indent="yes" omit-xml-declaration="yes"/>

    <xsl:template match="/">
		<payroll>
			<xsl:apply-templates select="/queryCompoundEmployeeResponse/CompoundEmployee"/>
		</payroll>
	</xsl:template>

    <!-- Get Params -->
	<xsl:param name="FileType"/>
	<xsl:param name="currentDateTime"/>
	<xsl:param name="LSRD"/>


    <xsl:template match="queryCompoundEmployeeResponse/CompoundEmployee">

        <xsl:if test="(person/employment_information[1]/job_information[1][(employee_class = 'REG')]/emplStatus = 'A') or (person/employment_information[1]/job_information[1][(employee_class = 'REG')]/emplStatus = 'U')">
            <record>
        <!-- Record Type -->                
                        <Record_Type>
                    	    <xsl:value-of select="$FileType"/>
                        </Record_Type>
  
        <!-- country -->                
                        <Emp_Country>
                    	   <xsl:value-of select="person/employment_information[1]/job_information[1]/company_territory_code"/>
                        </Emp_Country>
                        
      					 <Company_ID>
            	           <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string102"/>
            	         </Company_ID>

        				<EMP_NO>
            	           <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP'">
                                 <xsl:value-of select="person/custom_string1"/> 
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN'">
                                <xsl:value-of select="person/person_id_external"/> 
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                          </xsl:choose>  
            	        </EMP_NO>
 
 
                        <EMP_NAME>
                           <xsl:value-of select="person/personal_information[1]/formal_name"/>
                        </EMP_NAME> 
                        
                        <BATCH_NO>
                           <xsl:value-of select="person/custom_string1"/>
                        </BATCH_NO>                      
                        

                        <DISPLAY_NAME>
                           <xsl:value-of select="person/personal_information[1]/display_name"/>    
                        </DISPLAY_NAME> 
               
               
                      <BASE_WAGE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP'">
                                <xsl:value-of select="person/employment_information/compensation_information/paycompensation_recurring[pay_component = 'SG1001' or pay_component = 'SG1012']/paycompvalue"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN'">
                                <xsl:text></xsl:text>/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>   
                      </BASE_WAGE>
               
            
                       <PAY_TYPE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP'">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string96"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN'">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string84"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                       </PAY_TYPE>
                        
                        <PAY_GROUP>
                           <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP'">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string95"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN'">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string83"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                        </PAY_GROUP>
 
 
 
                    <DOB>
                       <xsl:value-of select="person/date_of_birth"/>                
                    </DOB>
                    
                    
                    <SEX>
                       <xsl:value-of select="person/personal_information[1]/gender"/>               
                    </SEX>
                    
                    
                    <MARITAL_STATUS>
                       <xsl:value-of select="person/personal_information[1]/marital_status"/>         
                    </MARITAL_STATUS>
                     
                     
                     
                    <SEX_TITLE>
                       <xsl:value-of select="person/personal_information[1]/salutation"/>        
                    </SEX_TITLE>
                    
                    
                    <RACE_CODE>
                        <xsl:choose>
                            <xsl:when test="person/personal_information[1]/personal_information_sgp/custom_string1 != ''">
                                <xsl:value-of select="person/personal_information[1]/personal_information_sgp/custom_string1"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </RACE_CODE>
                    
                    
                    <NATIONAL_CODE>
                        <xsl:choose>
                            <xsl:when test="person/personal_information[1]/nationality != ''">
                                <xsl:value-of select="person/personal_information[1]/nationality"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </NATIONAL_CODE>
                    
                    
                    <RELIGION_CODE>
                        <xsl:choose>
                            <xsl:when test="person/personal_information[1]/personal_information_sgp/genericString1 != ''">
                                <xsl:value-of select="person/personal_information[1]/personal_information_sgp/genericString1"/>
                            </xsl:when>
                            <xsl:when test="person/personal_information[1]/personal_information_idn/genericString5 != ''">
                                <xsl:value-of select="person/personal_information[1]/personal_information_idn/genericString5"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </RELIGION_CODE>
                    
                    
                    
                    <DIVISION_CODE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/custom_string101 != ''">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string101"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </DIVISION_CODE>
                    
                    
                    <DEPARTMENT_CODE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/custom_string101 != ''">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string101"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </DEPARTMENT_CODE>
                    
                    
                    <COST_CENTRE_CODE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/cost_center != ''">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/cost_center"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </COST_CENTRE_CODE>
                     
                      
                    <CATEGORY_CODE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/employee_class != ''">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/employee_class"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </CATEGORY_CODE>       
                      

                    <SECTION_CODE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/custom_string97 != ''">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string97"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </SECTION_CODE>
                    
                    
                    <OCCUPATION_CODE>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/job_title"/>
                    </OCCUPATION_CODE>
                      
                      
                      
                    <JOB_GRADE_CODE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/pay_grade != ''">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/pay_grade"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </JOB_GRADE_CODE>
                      
                      
                    <LEAVE_SCHEME_CODE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_leaveSchemes_Code"/>
                    </LEAVE_SCHEME_CODE>                    
                      
                      
                    <BENEFIT_SCHEME_CODE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_benefitScheme_Code"/>
                    </BENEFIT_SCHEME_CODE>                      
                      
                      
                      
                    <EDUCATION_CODE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/custom_string99 != ''">
                                <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string99"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>   
                    </EDUCATION_CODE>
                      
                    
                    <BANK_ID>
                          <xsl:value-of select="substring(person/employment_information[1]/PaymentInformationV3[1]/PaymentInformationDetailV3/bank,1,4)"/>
                    </BANK_ID>
                    
                    <BANK_BRANCH_CODE>
                          <xsl:value-of select="substring(person/employment_information[1]/PaymentInformationV3[1]/PaymentInformationDetailV3/bank,6,3)"/>
                    </BANK_BRANCH_CODE>
                    
                    <BANK_AC_NO>
                          <xsl:value-of select="person/employment_information[1]/PaymentInformationV3[1]/PaymentInformationDetailV3/accountNumber"/>
                    </BANK_AC_NO>
                    
                    <HIRED_DATE>
                          <xsl:value-of select="person/employment_information[1]/start_date"/>
                    </HIRED_DATE>  
                      
  
                    <EMPL_STATUS>
                     <xsl:text>AC</xsl:text>
                    </EMPL_STATUS> 
  
                      
                    <PROBATION_PERIOD>
                     <xsl:value-of select="substring(person/employment_information[1]/job_information[1]/custom_string103,1,1)"/>
                    </PROBATION_PERIOD> 
 
                     <PROBATION_PERIOD_BY>
                     <xsl:value-of select="substring(person/employment_information[1]/job_information[1]/custom_string103,3,5)"/>
                    </PROBATION_PERIOD_BY> 
 
                      
                    <PROBATION_PERIOD_END_DATE>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/probation_period_end_date"/>
                    </PROBATION_PERIOD_END_DATE> 
                      
                    <NATIONAL_ID>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP'">
                                <xsl:value-of select="person/national_id_card[isPrimary = 'true']/national_id"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN'">
                                <xsl:value-of select="person/national_id_card[card_type = 'NIK']/national_id"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </NATIONAL_ID>
                    
                    
                    <NATIONAL_CARD_TYPE>
                          <xsl:value-of select="person/national_id_card[isPrimary = 'true']/card_type"/>
                    </NATIONAL_CARD_TYPE>


                    <DOCUMENT_TYPE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP' and person/employment_information[1]/personal_documents_information[country = 'SGP' and (document_type = 'F1' or document_type = 'F2' or document_type = 'R1' or document_type = 'F8')]/document_type != ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[country = 'SGP' and  (document_type = 'F1' or document_type = 'F2' or document_type = 'R1' or document_type = 'F8')]/document_type"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN' and person/employment_information[1]/personal_documents_information[country = 'IDN' and (document_type = 'IDN1' or document_type = 'IDN2')]/document_type != ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[country = 'IDN' and (document_type = 'IDN1' or document_type = 'IDN2')]/document_type"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>   
                    </DOCUMENT_TYPE>


                    <TIER_CATEG>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP' and person/employment_information[1]/personal_documents_information[country = 'SGP' and (document_type = 'F1')]/custom_string1 != ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[country = 'SGP' and (document_type = 'F1')]/custom_string1"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN' and person/employment_information[1]/personal_documents_information[country = 'IDN' and (document_type = 'IDN1' or document_type = 'IDN2')]/document_type != ''">
                                 <xsl:text></xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>   
                    </TIER_CATEG>


                    <DOCUMENT_NUMBER>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP' and person/employment_information[1]/personal_documents_information[country = 'SGP' and (document_type = 'F1' or document_type = 'F2' or document_type = 'R1' or document_type = 'F8')]/document_number != ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[country = 'SGP' and  (document_type = 'F1' or document_type = 'F2' or document_type = 'R1' or document_type = 'F8')]/document_number"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN' and person/employment_information[1]/personal_documents_information[country = 'IDN' and (document_type = 'IDN1' or document_type = 'IDN2')]/document_type != ''">
                                <xsl:text></xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>   
                    </DOCUMENT_NUMBER>

                    <DOCUMENT_ISSUE_DATE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP' and person/employment_information[1]/personal_documents_information[country = 'SGP' and (document_type = 'F1' or document_type = 'F2' or document_type = 'R1' or document_type = 'F8')]/issue_date != ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[country = 'SGP' and  (document_type = 'F1' or document_type = 'F2' or document_type = 'R1' or document_type = 'F8')]/issue_date"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN' and person/employment_information[1]/personal_documents_information[country = 'IDN' and (document_type = 'IDN1' or document_type = 'IDN2')]/issue_date != ''">
                                <xsl:text></xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>   
                    </DOCUMENT_ISSUE_DATE>

                    <DOCUMENT_EXPIRY_DATE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP' and person/employment_information[1]/personal_documents_information[country = 'SGP' and (document_type = 'F1' or document_type = 'F2' or document_type = 'R1' or document_type = 'F8')]/expiration_date != ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[country = 'SGP' and  (document_type = 'F1' or document_type = 'F2' or document_type = 'R1' or document_type = 'F8')]/expiration_date"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN' and person/employment_information[1]/personal_documents_information[country = 'IDN' and (document_type = 'IDN1' or document_type = 'IDN2')]/expiration_date != ''">
                                <xsl:text></xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>   
                    </DOCUMENT_EXPIRY_DATE>
  
  
                    <PR_APPROVAL_DATE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP'">
                                <xsl:value-of select="person/national_id_card[isPrimary = 'true']/custom_date1"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN'">
                                <xsl:value-of select="person/national_id_card[card_type = 'NIK']/custom_date1"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>  
                    </PR_APPROVAL_DATE>                  
                    

        		    <BUS_EMAIL>
            	          <xsl:value-of select="person/email_information[(email_type = 'B') and (isPrimary = 'true')]/email_address"/>
            	    </BUS_EMAIL>

         	        
        			 <PRIV_EMAIL>
            	          <xsl:value-of select="person/email_information[(email_type = 'P') and (isPrimary = 'false')]/email_address"/>
            	     </PRIV_EMAIL>

                    <HOME_ADDR1>
                        <xsl:choose>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'SGP'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'SGP' and address_type = 'home']/address5,person/address_information[1][country = 'SGP' and address_type = 'home']/address1)" />
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'MYS'">
                                <xsl:value-of select="person/address_information[1][country = 'MYS' and address_type = 'home']/address1"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'IND'">
                                <xsl:value-of select="person/address_information[1][country = 'IND' and address_type = 'home']/address1"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'PHL'">
                                <xsl:value-of select="person/address_information[1][country = 'PHL' and address_type = 'home']/address2"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>    
                    </HOME_ADDR1>



                    <MAILING_ADDR1>
                        <xsl:choose>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'SGP'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'SGP' and address_type = 'mailing']/address5,person/address_information[1][country = 'SGP' and address_type = 'home']/address1)"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'MYS'">
                                <xsl:value-of select="person/address_information[1][country = 'MYS' and address_type = 'mailing']/address1"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'IND'">
                                <xsl:value-of select="person/address_information[1][country = 'IND' and address_type = 'mailing']/address1"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'PHL'">
                                <xsl:value-of select="person/address_information[1][country = 'PHL' and address_type = 'mailing']/address2"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>    
                    </MAILING_ADDR1>


                    <HOME_ADDR2>
                        <xsl:choose>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'SGP'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'SGP' and address_type = 'home']/address6,person/address_information[1][country = 'SGP' and address_type = 'home']/address2)" />
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'MYS'">
                                <xsl:value-of select="person/address_information[1][country = 'MYS' and address_type = 'home']/address2"/>
                            </xsl:when>
                             <xsl:when test="person/address_information[1][address_type = 'home']/country = 'IND'">
                                <xsl:value-of select="person/address_information[1][country = 'IND' and address_type = 'home']/address2"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'PHL'">
                                <xsl:value-of select="person/address_information[1][country = 'PHL' and address_type = 'home']/address3"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>    
                    </HOME_ADDR2>

                    <MAILING_ADDR2>
                        <xsl:choose>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'SGP'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'SGP' and address_type = 'mailing']/address6,person/address_information[1][country = 'SGP' and address_type = 'mailing']/address1, person/address_information[1][country = 'SGP' and address_type = 'mailing']/address8)"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'MYS'">
                                <xsl:value-of select="person/address_information[1][country = 'MYS' and address_type = 'mailing']/address2"/>
                            </xsl:when>
                             <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'IND'">
                                <xsl:value-of select="person/address_information[1][country = 'IND' and address_type = 'mailing']/address2"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'PHL'">
                                <xsl:value-of select="person/address_information[1][country = 'PHL' and address_type = 'mailing']/address3"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>    
                    </MAILING_ADDR2>


                    <HOME_ADDR3>
                        <xsl:choose>
                             <xsl:when test="person/address_information[1][address_type = 'home']/country = 'SGP'">
                                <xsl:value-of select="person/address_information[1][country = 'SGP' and address_type = 'home']/address3"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'MYS'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'MYS' and address_type = 'home']/address3,person/address_information[1][country = 'MYS' and address_type = 'home']/city)"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'IND'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'IND' and address_type = 'home']/address3,person/address_information[1][country = 'IND' and address_type = 'home']/city)"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'PHL'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'PHL' and address_type = 'home']/address5,person/address_information[1][country = 'PHL' and address_type = 'home']/city)"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>    
                    </HOME_ADDR3>

                    <MAILING_ADDR3>
                        <xsl:choose>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'SGP'">
                                <xsl:value-of select="person/address_information[1][country = 'SGP' and address_type = 'mailing']/address3"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'MYS'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'MYS' and address_type = 'mailing']/address3,person/address_information[1][country = 'MYS' and address_type = 'mailing']/city)"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'IND'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'IND' and address_type = 'mailing']/address3,person/address_information[1][country = 'IND' and address_type = 'mailing']/city)"/>
                            </xsl:when>
                            <xsl:when test="person/address_information[1][address_type = 'mailing']/country = 'PHL'">
                                <xsl:value-of select="concat(person/address_information[1][country = 'PHL' and address_type = 'mailing']/address5,person/address_information[1][country = 'PHL' and address_type = 'mailing']/city)"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>   
                    </MAILING_ADDR3>

                    <HOME_POST_CODE>
                        <xsl:value-of select="person/address_information[1][(address_type = 'home')]/zip_code"/>  
                    </HOME_POST_CODE>
        
        
                    <MAIL_POST_CODE>
                        <xsl:value-of select="person/address_information[1][(address_type = 'mailing')]/zip_code"/>  
                    </MAIL_POST_CODE>


                    <MOBILE_NO_CC>
                        <xsl:value-of select="person/phone_information[(isPrimary = 'true')]/country_code"/>  
                    </MOBILE_NO_CC>

                    <MOBILE_NO>
                        <xsl:value-of select="person/phone_information[(isPrimary = 'true')]/phone_number"/>  
                    </MOBILE_NO>

                    <PASSPORT_NO>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/personal_documents_information[(document_type = 'permitdoctype_CHN_Passport' or document_type = 'permitdoctype_Costa_Rica_CRI_Number~%1' or document_type = 'permitdoctype_Dominican_Republic_DOM_Passport' or document_type = 'ECU-04' or document_type = 'GBR_Passport' or document_type = '92' or document_type = 'permitdoctype_Honduras_HND_Passport' or document_type = 'IDN2' or document_type = 'IDN1' or document_type = 'IRL-01' or document_type = 'PS' or document_type = 'KHM-03' or document_type = 'KOR4' or document_type = 'KWT-02' or document_type = 'permitdoctype_Lebanon_LBN_Number~%1' or document_type = 'permitdoctype_MEX_Passport' or document_type = 'permitdoctype_MEX_Passport~%1' or document_type = 'MYS4' or document_type = 'permitdoctype_Panama_PAN_Number~%2' or document_type = 'permitdoctype_Peru_PER_Number~%2' or document_type = 'PHL-04' or document_type = 'POL3' or document_type = 'PRT2' or document_type = 'RUS2' or document_type = 'permitdoctype_SGP_Passport' or document_type = 'permitdoctype_THA_Passport' or document_type = 'THA2' or document_type = 'TWN7')]/document_number != ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[(document_type = 'permitdoctype_CHN_Passport' or document_type = 'permitdoctype_Costa_Rica_CRI_Number~%1' or document_type = 'permitdoctype_Dominican_Republic_DOM_Passport' or document_type = 'ECU-04' or document_type = 'GBR_Passport' or document_type = '92' or document_type = 'permitdoctype_Honduras_HND_Passport' or document_type = 'IDN2' or document_type = 'IDN1' or document_type = 'IRL-01' or document_type = 'PS' or document_type = 'KHM-03' or document_type = 'KOR4' or document_type = 'KWT-02' or document_type = 'permitdoctype_Lebanon_LBN_Number~%1' or document_type = 'permitdoctype_MEX_Passport' or document_type = 'permitdoctype_MEX_Passport~%1' or document_type = 'MYS4' or document_type = 'permitdoctype_Panama_PAN_Number~%2' or document_type = 'permitdoctype_Peru_PER_Number~%2' or document_type = 'PHL-04' or document_type = 'POL3' or document_type = 'PRT2' or document_type = 'RUS2' or document_type = 'permitdoctype_SGP_Passport' or document_type = 'permitdoctype_THA_Passport' or document_type = 'THA2' or document_type = 'TWN7')]/document_number"/>
                            </xsl:when>
                             <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </PASSPORT_NO>
  
  
                    <PASSPORT_ISSUE_DATE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/personal_documents_information[(document_type = 'permitdoctype_CHN_Passport' or document_type = 'permitdoctype_Costa_Rica_CRI_Number~%1' or document_type = 'permitdoctype_Dominican_Republic_DOM_Passport' or document_type = 'ECU-04' or document_type = 'GBR_Passport' or document_type = '92' or document_type = 'permitdoctype_Honduras_HND_Passport' or document_type = 'IDN2' or document_type = 'IDN1' or document_type = 'IRL-01' or document_type = 'PS' or document_type = 'KHM-03' or document_type = 'KOR4' or document_type = 'KWT-02' or document_type = 'permitdoctype_Lebanon_LBN_Number~%1' or document_type = 'permitdoctype_MEX_Passport' or document_type = 'permitdoctype_MEX_Passport~%1' or document_type = 'MYS4' or document_type = 'permitdoctype_Panama_PAN_Number~%2' or document_type = 'permitdoctype_Peru_PER_Number~%2' or document_type = 'PHL-04' or document_type = 'POL3' or document_type = 'PRT2' or document_type = 'RUS2' or document_type = 'permitdoctype_SGP_Passport' or document_type = 'permitdoctype_THA_Passport' or document_type = 'THA2' or document_type = 'TWN7')]/issue_date != ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[(document_type = 'MYS4')]/issue_date"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </PASSPORT_ISSUE_DATE>
   
   
                    <PASSPORT_EXPIRY_DATE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/personal_documents_information[(document_type = 'permitdoctype_CHN_Passport' or document_type = 'permitdoctype_Costa_Rica_CRI_Number~%1' or document_type = 'permitdoctype_Dominican_Republic_DOM_Passport' or document_type = 'ECU-04' or document_type = 'GBR_Passport' or document_type = '92' or document_type = 'permitdoctype_Honduras_HND_Passport' or document_type = 'IDN2' or document_type = 'IDN1' or document_type = 'IRL-01' or document_type = 'PS' or document_type = 'KHM-03' or document_type = 'KOR4' or document_type = 'KWT-02' or document_type = 'permitdoctype_Lebanon_LBN_Number~%1' or document_type = 'permitdoctype_MEX_Passport' or document_type = 'permitdoctype_MEX_Passport~%1' or document_type = 'MYS4' or document_type = 'permitdoctype_Panama_PAN_Number~%2' or document_type = 'permitdoctype_Peru_PER_Number~%2' or document_type = 'PHL-04' or document_type = 'POL3' or document_type = 'PRT2' or document_type = 'RUS2' or document_type = 'permitdoctype_SGP_Passport' or document_type = 'permitdoctype_THA_Passport' or document_type = 'THA2' or document_type = 'TWN7')]/expiration_date!= ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[(document_type = 'MYS4')]/expiration_date"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </PASSPORT_EXPIRY_DATE>                 
  
                    <EMERGENCY_ADDR>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'Y']/second_phone"/>  
                    </EMERGENCY_ADDR>
  
                    
                    <EMERGENCY_RELATION_P>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'Y']/relationship"/>  
                    </EMERGENCY_RELATION_P>

                    <EMERGENCY_RELATION_S>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'N']/relationship"/>  
                    </EMERGENCY_RELATION_S>

                    <EMERGENCY_MOBILE_P>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'Y']/phone"/>  
                    </EMERGENCY_MOBILE_P>

                    <EMERGENCY_MOBILE_S>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'N']/phone"/>  
                    </EMERGENCY_MOBILE_S>

                    <EMERGENCY_PHONE_P>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'Y']/second_phone"/>  
                    </EMERGENCY_PHONE_P>

                    <EMERGENCY_PHONE_S>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'N']/second_phone"/>  
                    </EMERGENCY_PHONE_S>

                    <EMERGENCY_EMAIL_P>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'Y']/email"/>  
                    </EMERGENCY_EMAIL_P>

                    <EMERGENCY_EMAIL_S>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'N']/email"/>  
                    </EMERGENCY_EMAIL_S>

                    <EMERGENCY_NAME_P>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'Y']/name"/>  
                    </EMERGENCY_NAME_P>

                    <EMERGENCY_NAME_S>
                        <xsl:value-of select="person/emergency_contact_primary[primary_flag = 'N']/name"/>  
                    </EMERGENCY_NAME_S>



                    <CLASSIFICATION_CD>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string2"/>
                    </CLASSIFICATION_CD>

                    <COUNTRY>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/company_territory_code"/>
                    </COUNTRY>


                    <LEAVE_SCHEME_ACTION_CODE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_leaveSchemesAction_Code"/>
                    </LEAVE_SCHEME_ACTION_CODE>


                    <LEAVE_SCHEME_EFF_DATE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_leaveScheme_Date"/>
                    </LEAVE_SCHEME_EFF_DATE>

                    <BENEFIT_SCHEME_EFF_DATE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_benefitScheme_Date"/>
                    </BENEFIT_SCHEME_EFF_DATE>

                    <NOTICE_PERIOD>
                     <xsl:value-of select="person/employment_information[1]/job_information[1]/employee_notice_period"/>
                    </NOTICE_PERIOD> 
 
                    <NOTICE_PERIOD_STARTDATE>
                      <xsl:value-of select="person/employment_information[1]/job_information[1]/notice_period_start_date"/>
                    </NOTICE_PERIOD_STARTDATE> 

                    <WP_APPL_DATE>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP' and person/employment_information[1]/personal_documents_information[country = 'SGP' and (document_type != 'permitdoctype_SGP_Passport')]/custom_date1 != ''">
                                 <xsl:value-of select="person/employment_information[1]/personal_documents_information[country = 'SGP' and (document_type != 'permitdoctype_SGP_Passport')]/custom_date1"/>
                            </xsl:when>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'IDN' and person/employment_information[1]/personal_documents_information[country = 'IDN' and (document_type = 'IDN1' or document_type = 'IDN2')]/expiration_date != ''">

                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>   
                    </WP_APPL_DATE>  


                    <HS_PLAN_TYPE>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string92"/>
                    </HS_PLAN_TYPE>

                    <EMPLOYEE_ID>
                        <xsl:value-of select="person/person_id_external"/>
                    </EMPLOYEE_ID>

                    <OCCUPATION>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string94"/>
                    </OCCUPATION>


                    <FUNCTION>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/division"/>
                    </FUNCTION>


                    <DEPARTMENT>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/department"/>
                    </DEPARTMENT>
                    

                    <CONTRACT_ENDDATE>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/contract_end_date"/>
                    </CONTRACT_ENDDATE>

                    <BUS_ROUTES>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_busRoutes"/>
                    </BUS_ROUTES>


                    <PROFESSIONAL_QUAL>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_profQualification"/>
                    </PROFESSIONAL_QUAL>


                    <DISCIPLINARY_ACTION>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_disciplinaryAction"/>
                    </DISCIPLINARY_ACTION>


                    <PIP>
                      <xsl:value-of select="person/cust_TimeSoft_Info/cust_PIP"/>
                    </PIP>


                    <HEAD_OF_DEPT>
                        <xsl:value-of select="person/employment_information[1]/job_relation[relationship_type = 'HOD']/user_id"/>
                    </HEAD_OF_DEPT>


                    <SUPERVISOR>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/manager_id"/>
                    </SUPERVISOR>

                    <TRNG_BOND_EXPIRY_DATE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_trainingBond_Date"/>
                    </TRNG_BOND_EXPIRY_DATE>


                    <EMP_BOND_EXPIRY_DATE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_empBond_expiryDate"/>
                    </EMP_BOND_EXPIRY_DATE>


                    <LAST_CHECK_DATE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_lastCheckup_date"/>
                    </LAST_CHECK_DATE>


                    <ANNUAL_WAGES_SUPPLEMENT>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_annualWagesNav/PickListValueV2/label_en_US"/>
                    </ANNUAL_WAGES_SUPPLEMENT>
                    
                    
                    <ANNUAL_MERIT_INCREMENT>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string9"/>
                    </ANNUAL_MERIT_INCREMENT>


                    <INELIGIBLITY_TRANSPORT_CA>
                        <xsl:text>TBD</xsl:text>
                    </INELIGIBLITY_TRANSPORT_CA>


                    <EIP>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP'">
                                <xsl:value-of select="person/employment_information/compensation_information/paycompensation_recurring[pay_component = 'SG1003']/paycompvalue"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>  
                    </EIP>

                    <SIP>
                        <xsl:choose>
                            <xsl:when test="person/employment_information[1]/job_information[1]/company_territory_code = 'SGP'">
                                <xsl:value-of select="person/employment_information/compensation_information/paycompensation_recurring[pay_component = 'SG1004']/paycompvalue"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>  
                    </SIP>


                    <BIRTH_COUNTRY>
                        <xsl:choose>
                            <xsl:when test="person/country_of_birth != ''">
                                <xsl:value-of select="person/country_of_birth"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>     
                    </BIRTH_COUNTRY>

                    <ORIGINAL_HIRED_DATE>
                        <xsl:value-of select="person/employment_information[1]/originalStartDate"/>
                    </ORIGINAL_HIRED_DATE>

<!-- BATAM EXTRA FIELDS STARTS FROM HERE --> 

                    <EMP_FIRST_NAME>                        
                        <xsl:value-of select="person/personal_information[1]/first_name"/>        <!-- BATAM 1--> 
                    </EMP_FIRST_NAME> 
    
 
                    <EMP_MIDDLE_NAME>
                        <xsl:value-of select="person/personal_information[1]/middle_name"/>            <!-- BATAM 2--> 
                    </EMP_MIDDLE_NAME> 

 
                    <EMP_LAST_NAME>
                       <xsl:value-of select="person/personal_information[1]/last_name"/>                 <!-- BATAM 3-->
                    </EMP_LAST_NAME> 


                    <BIRTH_PLACE>
                        <xsl:choose>
                            <xsl:when test="person/place_of_birth != ''">
                                <xsl:value-of select="person/place_of_birth"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </BIRTH_PLACE>

                    <LOCAL_EMPNO>
                        <xsl:value-of select="person/custom_string1"/>                <!-- BATAM 15-->
                    </LOCAL_EMPNO>


                    <BATAM_ADDR1>
                        <xsl:choose>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'IDN'">
                                <xsl:value-of select="person/address_information[1][country = 'IDN' and address_type = 'home']/address2"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>    
                    </BATAM_ADDR1>


                    <BATAM_STATE>
                        <xsl:choose>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'IDN'">
                                <xsl:value-of select="person/address_information[1][country = 'IDN' and address_type = 'home']/state"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>    
                    </BATAM_STATE>

                    <BATAM_ZIP>
                        <xsl:choose>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'IDN'">
                                <xsl:value-of select="person/address_information[1][country = 'IDN' and address_type = 'home']/zip_code"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>    
                    </BATAM_ZIP>


                    <BATAM_COUNTRY>
                        <xsl:choose>
                            <xsl:when test="person/address_information[1][address_type = 'home']/country = 'IDN'">
                                <xsl:value-of select="person/address_information[1][country = 'IDN' and address_type = 'home']/country"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text></xsl:text>/>
                            </xsl:otherwise>
                        </xsl:choose>    
                    </BATAM_COUNTRY>
                    
                    <DAYS_PER_WEEK>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/workingDaysPerWeek"/>
                    </DAYS_PER_WEEK>

                    <ANNUAL_HOURS>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/custom_string87"/>
                    </ANNUAL_HOURS>


                    <LOCAL_JOB_TITLE>
                        <xsl:value-of select="person/employment_information[1]/job_information[1]/local_job_title"/>
                    </LOCAL_JOB_TITLE>

                    <TS_EMPLOYEE_TYPE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_employeeTypeB"/>
                    </TS_EMPLOYEE_TYPE>

                    <BLOOD_TYPE>
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_bloodTypeB"/>
                    </BLOOD_TYPE>

                    <RACE>
                        <xsl:choose>
                            <xsl:when test="person/cust_TimeSoft_Info/cust_raceB != ''">
                                <xsl:value-of select="person/cust_TimeSoft_Info/cust_raceB"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NONE</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose> 
                    </RACE>
                    

                    <LAST_EDUCATION>                        
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_lastEducationB"/>
                    </LAST_EDUCATION> 
                    
                    <DIV_CODE>                        
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_divisionCodeB"/>
                    </DIV_CODE> 
                    
                    <PRODUCTIVITY>                        
                        <xsl:value-of select="person/cust_TimeSoft_Info/cust_productivityBNav/PickListValueV2/label_en_US"/>
                    </PRODUCTIVITY> 
                    
                    <INITIAL>
                        <xsl:value-of select="person/personal_information[1]/initials"/>
                    </INITIAL>
                    

        </record>
      </xsl:if>

    </xsl:template>
</xsl:stylesheet>
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0"
    xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" version="1.0" encoding="utf-8" indent="yes" omit-xml-declaration="yes"/>
    
    <!-- Get Params -->
	<xsl:param name="FileType"/>
    

    <xsl:template match="/">
		<payroll>
			<xsl:apply-templates select="/payroll/record"/>
		</payroll>
	</xsl:template>
    
	<xsl:template match="payroll/record">
	    <xsl:if test="Company_ID != ''">
          <record>
              
        <!-- Record Type -->                
                        <Record_Type>
                    	   <xsl:value-of select="$FileType"/>
                        </Record_Type>
                        
        <!-- Employee Country -->                
                        <Emp_Country>
                    	   <xsl:value-of select="Emp_Country"/>
                        </Emp_Country>                

        <!-- Company Code -->                
                        <company_code>
                    	   <xsl:value-of select="Company_ID"/>
                        </company_code>  

         <!-- Employee Number -->
        				<emp_no>
            	          <xsl:value-of select="EMP_NO"/>
            	        </emp_no> 

         <!-- Employee Name -->
        				<emp_name>
            	          <xsl:value-of select="EMP_NAME"/>
            	        </emp_name> 

        <!-- Local Employee Number -->
        				<batch_no>
            	          <xsl:value-of select="BATCH_NO"/>
            	        </batch_no> 

        <!-- Display Name -->
        				<emp_alias>
            	          <xsl:value-of select="DISPLAY_NAME"/>
            	        </emp_alias> 
            	        
         <!-- Basic Pay -->
        				<base_wage>
            	          <xsl:value-of select="BASE_WAGE"/>
            	        </base_wage>             	        
            	                  	        
        <!--  Paytype -->
        				<pay_type>
            	          <xsl:value-of select="PAY_TYPE"/>
            	        </pay_type>              	        
            	        
         <!--  Paygroup -->
        				<pay_group>
            	          <xsl:value-of select="PAY_GROUP"/>
            	        </pay_group>              	        
            	                   	        
         <!-- Date of birth -->
        				<dob>
            	          <xsl:value-of select="DOB"/>
            	        </dob>            	        
            	        
          <!-- Gender -->
        				<sex>
            	          <xsl:value-of select="SEX"/>
            	        </sex>           	        
            	        
        <!-- Marital Status -->
        				<marital_status>
            	          <xsl:value-of select="MARITAL_STATUS"/>
            	        </marital_status>             	        
            	        
          <!-- Title -->
        				<sex_title>
            	          <xsl:value-of select="SEX_TITLE"/>
            	        </sex_title>           	        
            	        
        <!-- Ethnicity -->
        				<race_code>
            	          <xsl:value-of select="RACE_CODE"/>
            	        </race_code>           	        
            	        
          <!-- Nationality -->
        				<national_code>
            	          <xsl:value-of select="NATIONAL_CODE"/>
            	        </national_code>
            	        
           <!-- Religion -->
        				<religion_code>
            	          <xsl:value-of select="RELIGION_CODE"/>
            	        </religion_code> 
            	        
            <!-- Division Code-->
        				<division_code>
            	          <xsl:value-of select="DIVISION_CODE"/>
            	        </division_code>            	        
            	        
             <!-- Cost Center-->
        				<cost_centre_code>
            	          <xsl:value-of select="COST_CENTRE_CODE"/>
            	        </cost_centre_code>              	        
            	        
             <!-- Employee Class-->
        				<category_code>
            	          <xsl:value-of select="CATEGORY_CODE"/>
            	        </category_code>             	        
            	        
            <!-- Section -->
        				<section_code>
            	          <xsl:value-of select="SECTION_CODE"/>
            	        </section_code>   
            	        
        <!-- Local Job Title -->
        				<occupation_code>
            	          <xsl:value-of select="OCCUPATION_CODE"/>
            	        </occupation_code>            	        
 
         <!-- Job grade code -->
        				<job_grade_code>
            	          <xsl:value-of select="JOB_GRADE_CODE"/>
            	        </job_grade_code>   
 
         <!-- Education Code -->
        				<education_code>
            	          <xsl:value-of select="EDUCATION_CODE"/>
            	        </education_code>   
 
            	        
        <!-- Bank Code -->
        				<bank_id>
            	          <xsl:value-of select="BANK_ID"/>
            	        </bank_id>           	        
            	        
        <!-- Bank Branch Code -->
        				<bank_branch_code>
            	          <xsl:value-of select="BANK_BRANCH_CODE"/>
            	        </bank_branch_code>    
            	        
        <!-- Bank Account No. -->
        				<bank_ac_no>
            	          <xsl:value-of select="BANK_AC_NO"/>
            	        </bank_ac_no>   
  
            <!-- Join date -->
        				<hired_date>
            	          <xsl:value-of select="HIRED_DATE"/>
            	        </hired_date>   
  
        <!-- Employee Status-->
        				<termination_status>
            	          <xsl:value-of select="EMPL_STATUS"/>
            	        </termination_status>

         <!-- Probation Period-->
        				<probation_prd>
            	          <xsl:value-of select="PROBATION_PERIOD"/>
            	        </probation_prd>

        <!-- Probationary Period End Date -->
        				<confirm_due_date>
            	          <xsl:value-of select="PROBATION_PERIOD_END_DATE"/>
            	        </confirm_due_date>

        <!-- National ID  -->
        				<new_ic>
            	          <xsl:value-of select="NATIONAL_ID"/>
            	        </new_ic> 
            	        
        <!-- Nation ID Card Type  -->
        				<fund_levy>
            	          <xsl:value-of select="NATIONAL_CARD_TYPE"/>
            	        </fund_levy> 

        <!-- WP Document Type  -->
        				<wp_type>
            	          <xsl:value-of select="DOCUMENT_TYPE"/>
            	        </wp_type> 

        <!-- WP Document Type  -->
        				<emp_pass_ac_no>
            	          <xsl:value-of select="DOCUMENT_NUMBER"/>
            	        </emp_pass_ac_no> 
            	        
        <!-- WP Issue Date  -->
        				<emp_pass_issue_date>
            	          <xsl:value-of select="DOCUMENT_ISSUE_DATE"/>
            	        </emp_pass_issue_date>     
            	        
        <!-- WP Expiration Date  -->
        				<emp_pass_expiry>
            	          <xsl:value-of select="DOCUMENT_EXPIRY_DATE"/>
            	        </emp_pass_expiry>             	        

        <!-- PR Approval Date  -->
        				<pr_approve_date>
            	          <xsl:value-of select="PR_APPROVAL_DATE"/>
            	        </pr_approve_date>   
            	        
        <!--Business Email information -->
        				<email_ac_no>
            	          <xsl:value-of select="BUS_EMAIL"/>
            	        </email_ac_no>   

        <!--Personal Email information -->
        				<personal_email>
            	          <xsl:value-of select="PRIV_EMAIL"/>
            	        </personal_email>  

        <!-- Home Address 1 -->
        				<addr1>
            	          <xsl:value-of select="HOME_ADDR1"/>
            	        </addr1> 
  
         <!-- Home Address 2 -->
        				<addr2>
            	          <xsl:value-of select="HOME_ADDR2"/>
            	        </addr2>  
  
        <!-- Home Address 3 -->
        				<addr3>
            	          <xsl:value-of select="HOME_ADDR3"/>
            	        </addr3> 
            	        
          <!-- Postal Code -->
        				<postal_code>
            	          <xsl:value-of select="HOME_POST_CODE"/>
            	        </postal_code>           	        
            	        
        <!-- Phone no country_code-->
        				<mobile_phone_cc>
            	          <xsl:value-of select="MOBILE_NO_CC"/>
            	        </mobile_phone_cc>            	        
            	        
        <!-- Phone no -->
        				<mobile_phone>
            	          <xsl:value-of select="MOBILE_NO"/>
            	        </mobile_phone>       


        <!-- Passport No -->
        				<passport_no>
            	          <xsl:value-of select="PASSPORT_NO"/>
            	        </passport_no> 

     
        <!-- Passport Issue Date  -->
        				<passport_issue_date>
            	          <xsl:value-of select="PASSPORT_ISSUE_DATE"/>
            	        </passport_issue_date>     
            	        
        <!--Passport Expiration Date  -->
        				<passport_expire_date>
            	          <xsl:value-of select="PASSPORT_EXPIRY_DATE"/>
            	        </passport_expire_date>             	        

          <!-- Emergency Relationship  -->
        				<emg_contact_relation>
            	          <xsl:value-of select="EMERGENCY_RELATION_P"/>
            	        </emg_contact_relation>            	        
            	        
         <!-- Emergency Mobile1  -->
        				<emg_mobile1>
            	          <xsl:value-of select="EMERGENCY_MOBILE_P"/>
            	        </emg_mobile1>      
            	        
           <!-- Emergency Mobile2  -->
        				<emg_mobile2>
            	          <xsl:value-of select="EMERGENCY_MOBILE_S"/>
            	        </emg_mobile2>  
 
 
          <!-- Emergency emg_tel  -->
        				<emg_tel>
            	          <xsl:value-of select="EMERGENCY_PHONE_P"/>
            	        </emg_tel>      
            	        
           <!-- Emergency emg_tel2  -->
        				<emg_tel2>
            	          <xsl:value-of select="EMERGENCY_PHONE_S"/>
            	        </emg_tel2>  
 
            	        
          <!-- Emergency contact person name 1  -->
        				<emergency_contact>
            	          <xsl:value-of select="EMERGENCY_NAME_P"/>
            	        </emergency_contact>    
     
            <!-- Emergency contact person name2  -->
        				<emergency_contact2>
            	          <xsl:value-of select="EMERGENCY_NAME_S"/>
            	        </emergency_contact2>     
     
             <!-- Labour Type  -->
        				<classification_code>
            	          <xsl:value-of select="CLASSIFICATION_CD"/>
            	        </classification_code>     
     
             <!-- Country  -->
        				<addr_country>
            	          <xsl:value-of select="COUNTRY"/>
            	        </addr_country>       
     
            <!-- Employee Notice Period -->
        				<notice_prd>
            	          <xsl:value-of select="NOTICE_PERIOD"/>
            	        </notice_prd>      
     
              <!-- Work Permit Application Date -->
        				<emp_pass_effective>
            	          <xsl:value-of select="WP_APPL_DATE"/>
            	        </emp_pass_effective>      
     
        <!-- H and S Plan -->
        				<char2>
            	          <xsl:value-of select="HS_PLAN_TYPE"/>
            	        </char2>          
        
        <!-- Employee ID  -->
        				<char1>
            	          <xsl:value-of select="EMPLOYEE_ID"/>
            	        </char1>        
        
         <!-- Occupation  -->
        				<char3>
            	          <xsl:value-of select="OCCUPATION"/>
            	        </char3>         
            
        <!-- Function   -->
        				<char4>
            	          <xsl:value-of select="FUNCTION"/>
            	        </char4>     
     
        <!-- Department    -->
        				<char5>
            	          <xsl:value-of select="DEPARTMENT"/>
            	        </char5> 
            	        
         <!-- Contract End Date -->
        				<char6>
            	          <xsl:value-of select="CONTRACT_ENDDATE"/>
            	        </char6>          
            	        
        <!-- BUS ROUTES -->
        				<char14>
            	          <xsl:value-of select="BUS_ROUTES"/>
            	        </char14>             	        

        <!-- HEAD OF DEPARTMENT -->
        				<char12>
            	          <xsl:value-of select="HEAD_OF_DEPT"/>
            	        </char12>

        <!-- Supervisor  -->
        				<char13>
            	          <xsl:value-of select="SUPERVISOR"/>
            	        </char13>

        <!-- Eligible for Compensation  -->
        				<boolean2>
            	          <xsl:value-of select="ANNUAL_MERIT_INCREMENT"/>
            	        </boolean2>
            	        
        <!-- EIP % -->
        				<numeric1>
            	          <xsl:value-of select="EIP"/>
            	        </numeric1>

        <!-- SIP % -->
        				<numeric2>
            	          <xsl:value-of select="SIP"/>
            	        </numeric2>

        <!-- Country of Birth -->
        				<dobctry>
            	          <xsl:value-of select="BIRTH_COUNTRY"/>
            	        </dobctry> 

         <!-- Original Hire Date -->
        				<ori_hired_date>
            	          <xsl:value-of select="ORIGINAL_HIRED_DATE"/>
            	        </ori_hired_date> 
 
          </record>
        </xsl:if>
	</xsl:template>
</xsl:stylesheet>

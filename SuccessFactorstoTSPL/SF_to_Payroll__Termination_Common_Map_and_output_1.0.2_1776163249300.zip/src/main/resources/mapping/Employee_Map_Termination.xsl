<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0"
    xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" version="1.0" encoding="utf-8" indent="yes" omit-xml-declaration="yes"/>

    <xsl:template match="/">
		<Payroll>
			<xsl:apply-templates select="/queryCompoundEmployeeResponse/CompoundEmployee"/>
		</Payroll>
	</xsl:template>

    <!-- Get Params -->
	<xsl:param name="LSRD"/>


    <xsl:template match="queryCompoundEmployeeResponse/CompoundEmployee">

        <xsl:if test="//person_id_external != ''">
            <record>

        <!-- country -->                
                        <Emp_Country>
                    	   <xsl:value-of select="person/employment_information[1]/job_information[1]/company_territory_code"/>
                        </Emp_Country>

        <!-- local Employee number -->
                        <EMP_No>
                    	   <xsl:value-of select="person/custom_string1"/>
                        </EMP_No>

        <!-- Employee number -->
                        <BATCH_NO>
                    	   <xsl:value-of select="person/custom_string1"/>
                        </BATCH_NO>


       <!-- payrollEndDate -->    
        			    <LAST_PAYMENT_DATE>
            	           <xsl:value-of select="person/employment_information[1]/payrollEndDate" />
            	        </LAST_PAYMENT_DATE>

       <!-- Termination Date -->    
        			    <TERMINATION_DATE>
            	           <xsl:value-of select="person/employment_information[1]/end_date" />
            	        </TERMINATION_DATE>


       <!-- Termination Status -->    
        			    <TERMINATION_STATUS>
            	           <xsl:value-of select="person/employment_information[1]/job_information[1]/emplStatus" />
            	        </TERMINATION_STATUS>


         <!-- Termination reason -->    	       
        				<REASON_TERMINATION_CODE>
            	           <xsl:value-of select="person/employment_information/job_information[1]/event_reason"/>
            	        </REASON_TERMINATION_CODE>


         <!-- Notice Period Start date -->    	       
        				<TENDER_DATE>
            	           <xsl:value-of select="person/employment_information[1]/job_information[1]/notice_period_start_date"/>
            	        </TENDER_DATE>
                       
            </record>
        </xsl:if>

    </xsl:template>
</xsl:stylesheet>
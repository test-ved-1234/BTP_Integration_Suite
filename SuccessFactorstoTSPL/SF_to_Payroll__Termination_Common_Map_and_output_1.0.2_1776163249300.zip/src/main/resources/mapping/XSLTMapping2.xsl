<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0"
    xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" version="1.0" encoding="utf-8" indent="yes" omit-xml-declaration="yes"/>

    <xsl:template match="/">
		<Payroll>
			<xsl:apply-templates select="/Payroll/record"/>
		</Payroll>
	</xsl:template>

    <!-- Get Params -->
	<xsl:param name="LSRD"/>


   	<xsl:template match="Payroll/record">

        <xsl:if test="//EMP_No != ''">
            <record>

        <!-- local Employee number -->
                        <emp_no>
                    	   <xsl:value-of select="EMP_No"/>
                        </emp_no>

        <!-- Last Payment Date -->
                        <last_payment_date>
                    	   <xsl:value-of select="LAST_PAYMENT_DATE"/>
                        </last_payment_date>
                        
       <!-- Termination Date -->    
        			    <termination_date>
            	           <xsl:value-of select="TERMINATION_DATE" />
            	        </termination_date>

       <!-- Termination Status -->    
        			    <termination_status>
            	           <xsl:value-of select="TERMINATION_STATUS" />
            	        </termination_status>
            	        
       <!-- Reason Termination Code -->    
        			    <reason_terminate_code>
            	           <xsl:value-of select="REASON_TERMINATION_CODE" />
            	        </reason_terminate_code>
            	        
        <!-- Termination Tender Date -->    
        			    <tender_date>
            	           <xsl:value-of select="TENDER_DATE" />
            	        </tender_date>           	        
            	        
            </record>
        </xsl:if>

    </xsl:template>
</xsl:stylesheet>
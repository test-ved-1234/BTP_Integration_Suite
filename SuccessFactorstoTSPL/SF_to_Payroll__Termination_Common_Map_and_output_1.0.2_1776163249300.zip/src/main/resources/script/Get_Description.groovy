import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;
import groovy.time.TimeCategory;
import java.util.HashMap;


def String GetCompanyDesc(String in_CompanyCode, MappingContext context)
{
    HashMap<String,String> CompanyStore = context.getProperty("CompanyStore");

    ans = in_CompanyCode;
    
    if(in_CompanyCode != "" || in_CompanyCode != null || in_CompanyCode != "null")
    {
        if(CompanyStore.containsKey(in_CompanyCode))
        {
            ans = CompanyStore.get(in_CompanyCode);
        }
    }
    return ans;
}
    
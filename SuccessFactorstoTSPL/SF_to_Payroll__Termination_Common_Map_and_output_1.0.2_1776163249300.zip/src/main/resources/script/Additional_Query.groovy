import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

       def map = message.getProperties();
       def employees = map.get("adhoc_employees");
       def companies = map.get("companies");
       def Adhoc_lsrd = map.get("adhoc_lsrd");
       def Last_Execution = map.get("last_execution");
       
       ArrayList employeeList = employees.split(",");
       ArrayList companyList = companies.split(",");
       
       def query_employee = "";
       def query_company = "";
       def query_lsrd = "";
       
       def On_Demand = "No";  

// Split input/adhoc employees and frame query       
       if( employees != null && employees != "" && employeeList.size() > 0 )
       {
           query_employee = "AND person_id_external IN (";
           for(def i = 0; i < employeeList.size(); i++ )
           {
               query_employee = query_employee + "'" + employeeList[i] + "'";
               
               if( i + 1 < employeeList.size() )
               {
                   query_employee += ",";
               }
           }
           query_employee += ")";
           
           On_Demand = "Yes" // Populate this global variable which will be used across integration
       }

// Split input companies and frame query       
       if( companies != null && companies != "" && companyList.size() > 0 )
       {
           query_company = "AND company IN (";
           for(def i = 0; i < companyList.size(); i++ )
           {
               query_company = query_company + "'" + companyList[i] + "'";
               
               if( i + 1 < companyList.size() )
               {
                   query_company += ",";
               }
           }
           query_company += ")";
       }

// Check whether the manual lsrd is entered
       if( Adhoc_lsrd != null && Adhoc_lsrd != "" )
        {
         query_lsrd = Adhoc_lsrd;
        }
        else
        {
         query_lsrd = Last_Execution;   
        }

       message.setProperty("employee_query", query_employee);
       message.setProperty("company_query", query_company);
       message.setProperty("Adhoc_Run",On_Demand);
       message.setProperty("LSRD", query_lsrd);
       return message;
}
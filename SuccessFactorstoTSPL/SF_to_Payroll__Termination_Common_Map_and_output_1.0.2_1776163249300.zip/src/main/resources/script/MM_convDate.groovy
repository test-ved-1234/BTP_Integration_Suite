import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;
import groovy.time.TimeCategory;
import java.util.HashMap;
import java.util.*;
import com.sap.it.api.securestore.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
//Import for Fetching Secure Parameters
import com.sap.it.api.ITApi;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;

def String convDate(String theDate, String inputPattern, String outputPattern) {

	String outDate = "";
	
	if (theDate != "") {
    	def date = Date.parse(inputPattern, theDate);
        outDate = date.format(outputPattern);
	}

    return outDate;

}

def Message logData(String logTitle, Message message) {
    String timeStamp = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
    map = message.getProperties();
    Enable_Logging = map.get("EnableLogging");
    if (Enable_Logging.toUpperCase() == "TRUE"){
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        String title = timeStamp + " " + logTitle;
        messageLog.addAttachmentAsString(title, body, "text/xml");
        }
    }
return message;
}

def Message JSONResponse(Message message){
    logData('JSON Response', message);
}

def Message JSONPost(Message message){
    logData('JSON Post', message);
}




import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.json.*

Message processData(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)
    def list = json.record
    def output = JsonOutput.prettyPrint(JsonOutput.toJson(list))
    message.setBody(output)
    return message
}

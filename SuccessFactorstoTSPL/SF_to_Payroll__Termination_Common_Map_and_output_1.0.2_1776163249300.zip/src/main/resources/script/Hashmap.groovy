import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

def Message InitiateHashMap(Message message) 
{

 def map = message.getProperties();
 String Temp = "0"

 HashMap<String, String> hmap1 = new HashMap<String, String>();
 HashMap<String, String> hmap2 = new HashMap<String, String>();

 message.setProperty("Pers_Term_Success",hmap1);
 message.setProperty("Pers_Term_Adhoc",hmap2);


 HashMap<String, String> cacheData1 = map.get("Pers_Term_Success");
 cacheData1.put("PersTermSuccess",Temp)
 message.setProperty("Pers_Term_Success",cacheData1);
 
 HashMap<String, String> cacheData2 = map.get("Pers_Term_Adhoc");
 cacheData2.put("PersTermAdhoc",Temp)
 message.setProperty("Pers_Term_Adhoc",cacheData2);
 
   return message;
}


//Increment the Personal Term Dated record
def Message Incr_Pers_Term_Success(Message message) {
    
    String RecordsFound = "";
    //def map = message.getHeaders();
    def map = message.getProperties();
    def output = map.get("Pers_Term_Success");
    def value=output.get("PersTermSuccess");
    
    int count = value.toInteger() + 1;
    
    HashMap<String, String> cacheData = map.get("Pers_Term_Success");
	cacheData.put("PersTermSuccess",count.toString())
	message.setProperty("Pers_Term_Success",cacheData);
	
	return message;
}

//Get the Personal Term Dated record count
def Message Get_Pers_Term_count(Message message) {
    
    String RecordsFound = "";

    def map = message.getProperties();
    
    def output2 = map.get("Pers_Term_Success");
    def value2=output2.get("PersTermSuccess");  
 
    message.setProperty("Pers_Term_Success_count",value2);
        
	return message;
}


//Update the Term Run Type
def Message UpdateRunType_Term(Message message) {
    
    String RecordsFound = "";
    def map = message.getProperties();
    def adhoc_val = map.get("Adhoc_Run"); //Get On demand Run
    
    HashMap<String, String> cacheData = map.get("Pers_Term_Adhoc");
	cacheData.put("PersTermAdhoc",adhoc_val.toString())
	message.setProperty("Pers_Term_Adhoc",cacheData);
	
	return message;
}

//Get the Term Run Type
def Message Get_Term_RunType(Message message) {
    
    String RecordsFound = "";

    def map = message.getProperties();
    
    def output2 = map.get("Pers_Term_Adhoc");
    def value2=output2.get("PersTermAdhoc");  
 
    message.setProperty("Pers_Term_Adhoc",value2);
        
	return message;
}
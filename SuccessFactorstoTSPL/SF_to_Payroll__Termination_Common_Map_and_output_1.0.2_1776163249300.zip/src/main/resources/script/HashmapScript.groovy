import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

class CompanyStruct{                 //Create the data structure to hold company data
    String companyId = ""
    String startDate = "";
    String companyName = "";
}

def Message Init(Message message){

    HashMap<String, CompanyStruct> mapCompanyStruct = new HashMap<String, CompanyStruct>();    //HashMap for Company structure
    HashMap<String, String> startDateStore = new HashMap<String, String>();                    //HashMap to hold company id and start date
    HashMap<String, String> CompanyStore = new HashMap<String,String>();                       //HashMap to hold company id and description

    message.setProperty("mapCompanyStruct",mapCompanyStruct);      //Set property for Map of Company structure                        
    message.setProperty("startDateStore",startDateStore);          //Set Start date store
    message.setProperty("CompanyStore",CompanyStore);              //Set company store

    return message;
}


def Message cacheCompany(Message message){
    def body = message.getBody(java.lang.String);
    def properties = message.getProperties();
    
    HashMap<String, CompanyStruct> mapCompanyStruct = properties.get("mapCompanyStruct");  //Create HashMap for Company Structure
    HashMap<String, String> startDateStore = properties.get("startDateStore");             //Create HashMap for Start date
    HashMap<String, String> CompanyStore = properties.get("CompanyStore")                  //Create HashMap for company id and description

    
    def xmlBody = new XmlParser().parseText(body);
    
    xmlBody.FOCompany.each {b ->                                     //Loop through each company code fetched in the query 
        if(!mapCompanyStruct.containsKey(b.externalCode.text()))     // If the company id is not present in the existing structure
        {
            CompanyStruct ee = new CompanyStruct();           
            mapCompanyStruct.put(b.externalCode.text(),ee);          //Put the external code in the company structure map
            
            ee.companyId = b.externalCode.text()                     //Pass the externalCode to the structure
            ee.companyName = b.name.text();                          //Pass the name/description to the structure
            ee.startDate = b.startDate.text();                       //Pass the start date to the structure

        }
        else
        {
            CompanyStruct be = mapCompanyStruct.get(b.externalCode.text());  //Pass the externalCode to the structure
            be.companyName = b.name.text();                                  //Pass the name/description to the structure
            be.startDate = b.startDate.text();                               //Pass the start date to the structure
        }
    }
    
    mapCompanyStruct.each {key, l ->
        startDateStore.put(l.companyId,l.startDate);           //Pass the company id and startDate to the structure
        CompanyStore.put(l.companyId, l.companyName);          //Pass the companyId and name to the structure
    }
    
    message.setProperty("startDateStore",startDateStore);      //Set property for startDateStore
    message.setProperty("CompanyStore",CompanyStore);          //Set property for CompanyStore
    return message;
}
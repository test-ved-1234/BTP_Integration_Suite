import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;
import groovy.time.TimeCategory;
import java.util.HashMap;
import java.util.*;
import com.sap.it.api.securestore.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
//Import for Fetching Secure Parameters
import com.sap.it.api.ITApi;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;





def Message GetSecureParamSGP(Message message) {
    //Body 
       def body = message.getBody();
       String password;

       def service = ITApiFactory.getApi(SecureStoreService.class, null);

       //Password from secure params
       def credential = service.getUserCredential("TSPL_Credentials_SGP"); 
        if (credential == null)
        { 
          throw new IllegalStateException("No credential found for alias 'TSPL_Credentials_SGP'");             
        }
        else
        {
          password = new String(credential.getPassword());
        }

         String auth = "Bearer" + " " + password;

        message.setHeader("Authorization",auth);
       return message;
}



def Message GetSecureParamIDN(Message message) {
    //Body 
       def body = message.getBody();
       String password1;

       def service1 = ITApiFactory.getApi(SecureStoreService.class, null);

       //Password from secure params
       def credential = service1.getUserCredential("TSPL_Credentials_BATAM"); 
        if (credential == null)
        { 
          throw new IllegalStateException("No credential found for alias 'TSPL_Credentials_BATAM'");             
        }
        else
        {
          password1 = new String(credential.getPassword());
        }

         String auth = "Bearer" + " " + password1;

        message.setHeader("Authorization",auth);
       return message;
}